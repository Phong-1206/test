from time import sleep
import sys
# report a message
print('Main process running')
# block for a moment
sleep(2)
# exit the main process
print('Exiting...')
sys.exit(0)
# never gets here
print('Never gets here...')